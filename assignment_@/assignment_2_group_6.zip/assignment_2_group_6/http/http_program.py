import requests
import logging

# Configure logging
logging.basicConfig(
    filename="http_errors.log",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

BASE_URL = "https://httpbin.org"


def get_request():
    print("\n========== HTTP GET REQUEST ==========")

    try:
        response = requests.get(
            f"{BASE_URL}/get",
            timeout=10
        )

        print("Request Method : GET")
        print("Status Code    :", response.status_code)

        print("\nResponse Headers:")
        for key, value in response.headers.items():
            print(f"{key}: {value}")

        print("\nResponse Body:")
        print(response.text[:2000])

    except requests.RequestException as error:
        print("GET request failed:", error)
        logging.error("GET request failed: %s", error)


def post_request():
    print("\n========== HTTP POST REQUEST ==========")

    data = {
        "name": "Student",
        "course": "Computer Networks",
        "protocol": "HTTP"
    }

    try:
        response = requests.post(
            f"{BASE_URL}/post",
            json=data,
            timeout=10
        )

        print("Request Method : POST")
        print("Status Code    :", response.status_code)

        print("\nResponse Headers:")
        for key, value in response.headers.items():
            print(f"{key}: {value}")

        print("\nResponse Body:")
        print(response.text[:2000])

    except requests.RequestException as error:
        print("POST request failed:", error)
        logging.error("POST request failed: %s", error)


if __name__ == "__main__":
    print("APPLICATION LAYER PROTOCOL - HTTP")

    get_request()
    post_request()

    print("\nHTTP program completed.")
