import dns.resolver
import logging

DOMAIN = "www.github.com"
OUTPUT_FILE = "dns_results.txt"

logging.basicConfig(
    filename="dns_queries.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)


def query_record(domain, record_type):
    print(f"\n--- {record_type} RECORD ---")

    try:
        answers = dns.resolver.resolve(domain, record_type)

        for answer in answers:
            print(answer)
            logging.info(
                "%s %s -> %s",
                domain,
                record_type,
                answer
            )

            with open(OUTPUT_FILE, "a", encoding="utf-8") as file:
                file.write(
                    f"{domain} {record_type} -> {answer}\n"
                )

    except dns.resolver.NoAnswer:
        print(f"No {record_type} record found.")
        logging.warning(
            "No %s record found for %s",
            record_type,
            domain
        )

    except dns.resolver.NXDOMAIN:
        print("Domain does not exist.")
        logging.error("NXDOMAIN: %s", domain)

    except Exception as error:
        print(f"DNS query failed: {error}")
        logging.exception(
            "DNS query failed for %s %s",
            domain,
            record_type
        )


def main():
    print("========== DNS PROGRAM ==========")
    print("Domain:", DOMAIN)

    # Clear previous result file
    with open(OUTPUT_FILE, "w", encoding="utf-8") as file:
        file.write(f"DNS Query Results for {DOMAIN}\n")
        file.write("=" * 50 + "\n")

    # Resolve IP address
    print("\n========== IP ADDRESS ==========")

    try:
        ip_addresses = dns.resolver.resolve(DOMAIN, "A")

        for ip in ip_addresses:
            print("IP Address:", ip)

            with open(OUTPUT_FILE, "a", encoding="utf-8") as file:
                file.write(f"A -> {ip}\n")

            logging.info("A record for %s -> %s", DOMAIN, ip)

    except Exception as error:
        print("Could not resolve IP address:", error)
        logging.exception("A record lookup failed.")

    # Query different DNS records
    query_record(DOMAIN, "A")
    query_record(DOMAIN, "MX")
    query_record(DOMAIN, "CNAME")

    print("\nResults saved to:", OUTPUT_FILE)
    print("DNS query log saved to: dns_queries.log")
    print("\nDNS program completed.")


if __name__ == "__main__":
    main()
