from ftplib import FTP
from pathlib import Path

HOST = "127.0.0.1"
PORT = 2121
USERNAME = "student"
PASSWORD = "12345"

def main():
    local_upload = Path("upload_test.txt")
    local_upload.write_text(
        "This file was uploaded using Python FTP.\n"
        "Computer Networks Lab Assignment 2.\n",
        encoding="utf-8"
    )

    downloaded = Path("downloaded_server_file.txt")

    print("===== FTP CLIENT =====")
    try:
        ftp = FTP()
        print("Connecting to FTP server...")
        ftp.connect(HOST, PORT, timeout=10)
        print("Connected.")

        ftp.login(USERNAME, PASSWORD)
        print("Login successful.")

        print("\n===== SERVER DIRECTORY =====")
        ftp.retrlines("LIST")

        print("\n===== UPLOAD =====")
        with open(local_upload, "rb") as file:
            ftp.storbinary("STOR uploaded_test.txt", file)
        print("Upload successful: uploaded_test.txt")

        print("\n===== DIRECTORY AFTER UPLOAD =====")
        ftp.retrlines("LIST")

        print("\n===== DOWNLOAD =====")
        with open(downloaded, "wb") as file:
            ftp.retrbinary("RETR server_file.txt", file.write)
        print("Download successful: server_file.txt")

        content = downloaded.read_text(encoding="utf-8")
        print("\nDownloaded file content:")
        print(content)

        print("Content verification: SUCCESS")
        ftp.quit()
        print("\nFTP connection closed.")

    except Exception as e:
        print("FTP Error:", e)

if __name__ == "__main__":
    main()
