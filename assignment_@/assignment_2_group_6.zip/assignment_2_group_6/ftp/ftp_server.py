from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from pathlib import Path

BASE_DIR = Path(__file__).parent / "ftp_root"
BASE_DIR.mkdir(exist_ok=True)

(BASE_DIR / "server_file.txt").write_text(
    "This file was created on the FTP server.\n"
    "Computer Networks Lab Assignment 2.\n",
    encoding="utf-8"
)

authorizer = DummyAuthorizer()
authorizer.add_user("student", "12345", str(BASE_DIR), perm="elradfmwMT")

handler = FTPHandler
handler.authorizer = authorizer

server = FTPServer(("127.0.0.1", 2121), handler)

print("FTP server started.")
print("Host: 127.0.0.1")
print("Port: 2121")
print("Username: student")
print("Password: 12345")
print("Press Ctrl+C to stop the server.")

server.serve_forever()
