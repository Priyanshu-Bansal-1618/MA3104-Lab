import smtplib
import logging
from email.message import EmailMessage
from getpass import getpass

logging.basicConfig(
    filename="smtp_log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(message)s"
)

def main():
    smtp_server = "smtp.gmail.com"
    smtp_port = 587

    sender = input("Enter sender Gmail address: ")
    password = getpass("Enter Gmail App Password: ")
    recipient = input("Enter recipient email address: ")

    message = EmailMessage()
    message["Subject"] = "Computer Networks Lab - SMTP Test"
    message["From"] = sender
    message["To"] = recipient
    message.set_content(
        "This is a test email sent using Python SMTP.\n"
        "Computer Networks Lab Assignment 2."
    )

    try:
        print("Connecting to SMTP server...")
        logging.info("Connecting to %s:%s", smtp_server, smtp_port)

        with smtplib.SMTP(smtp_server, smtp_port, timeout=20) as server:
            server.ehlo()
            logging.info("EHLO sent")
            print("Starting TLS...")
            server.starttls()
            server.ehlo()
            logging.info("TLS connection established")

            print("Logging in...")
            server.login(sender, password)
            logging.info("SMTP login successful")

            print("Sending email...")
            server.send_message(message)
            logging.info("Email sent successfully")

        print("\nEmail sent successfully.")
        print("Communication log saved to smtp_log.txt")

    except Exception as e:
        logging.exception("SMTP operation failed")
        print("\nSMTP Error:", e)
        print("Check your Gmail address and App Password.")

if __name__ == "__main__":
    main()
